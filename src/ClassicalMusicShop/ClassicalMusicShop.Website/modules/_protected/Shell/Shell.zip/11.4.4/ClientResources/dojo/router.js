//>>built
define("dojo/router",["./router/RouterBase"],function(_1){return new _1({});});