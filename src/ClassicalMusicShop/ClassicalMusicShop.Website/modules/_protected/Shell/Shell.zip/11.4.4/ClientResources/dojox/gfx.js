//>>built
define("dojox/gfx",["dojo/_base/lang","./gfx/_base","./gfx/renderer!"],function(_1,_2,_3){_2.switchTo(_3);return _2;});