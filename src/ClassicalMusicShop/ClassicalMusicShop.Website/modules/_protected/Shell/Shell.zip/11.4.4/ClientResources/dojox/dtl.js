//>>built
define("dojox/dtl",["./dtl/_base"],function(_1){return _1;});