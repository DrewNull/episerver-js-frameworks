//>>built
define("dojox/fx",["./fx/_base"],function(_1){return _1;});