//>>built
define("dojo/NodeList",["./query"],function(_1){return _1.NodeList;});