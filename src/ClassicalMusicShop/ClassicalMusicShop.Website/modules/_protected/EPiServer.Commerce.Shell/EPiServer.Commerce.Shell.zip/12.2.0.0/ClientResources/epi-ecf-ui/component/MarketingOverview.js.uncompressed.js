require({cache:{
'url:epi-ecf-ui/component/templates/MarketingOverview.html':"<div>\r\n\t<div data-dojo-attach-point=\"toolbar\" data-dojo-type=\"epi-ecf-ui/widget/MarketingToolbar\" class=\"epi-viewHeaderContainer epi-localToolbar clearfix\"></div>\r\n    <div data-dojo-attach-point=\"leftPaneContainer\" class=\"epi-marketing__leftPane\">\r\n        <div data-dojo-attach-point=\"searchBoxContainer\" class=\"epi-gadgetInnerToolbar\"></div>\r\n    </div>\r\n    <div data-dojo-type=\"epi-ecf-ui/widget/CampaignItemList\" data-dojo-attach-point=\"campaignItemList\"></div>\r\n</div>"}});
define("epi-ecf-ui/component/MarketingOverview", [
    "dojo/_base/declare",
    "dojo/dom-geometry",
    "dojo/when",
// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/layout/_LayoutWidget",
// epi
    "epi/shell/_ContextMixin",
    "epi/dependency",
    "../widget/FacetGroupList",
    "epi-cms/widget/SearchBox",
    "../widget/viewmodel/MarketingFacetGroupViewModel",
    "../widget/viewmodel/MarketingFacetGroupListViewModel",
// resources
    "dojo/text!./templates/MarketingOverview.html",
// Widgets in the template
    "../widget/CampaignItemList",
    "../widget/MarketingToolbar"
], function (
    declare,
    domGeometry,
    when,
// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _LayoutWidget,
// epi
    _ContextMixin,
    dependency,
    FacetGroupList,
    SearchBox,
    MarketingFacetGroupViewModel,
    MarketingFacetGroupListViewModel,    
// resources
    template
) {

    return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContextMixin], {
        // summary:
        //      This is the initializer of Marketing Overview.

        templateString: template,

        postCreate: function () {
            this._searchBox = new SearchBox();
            this.own(this._searchBox);

            var contentRepositoryDescriptors = dependency.resolve("epi.cms.contentRepositoryDescriptors");

            this._searchBox.set("area", "Commerce/Campaigns");
            this._searchBox.set("searchRoots", contentRepositoryDescriptors.marketing.roots[0]);

            this._searchBox.placeAt(this.searchBoxContainer);

            var campaignFacetSettings = {
                itemViewModelClass: MarketingFacetGroupViewModel,
                listViewModelClass: MarketingFacetGroupListViewModel
            };
            this._campaignFacet = new FacetGroupList(campaignFacetSettings);
            this.own(this._campaignFacet);

            this._campaignFacet.placeAt(this.leftPaneContainer);

            this.inherited(arguments);
        },

        updateView: function (data, context) {
            // summary:
            //      Updates the view, to reflect data changes.(when opening this view second time)
            // tags:
            //      protected

            this.toolbar.update({
                currentContext: context,
                viewConfigurations: {
                    availableViews: data.availableViews,
                    viewName: data.viewName
                }
            });
        },

        layout: function () {
            // summary:
            //      Layout the children widgets.
            // tags:
            //      protected

            this.inherited(arguments);

            var toolbarSize = domGeometry.getMarginBox(this.toolbar.domNode),
                leftPaneSize = domGeometry.getMarginBox(this.leftPaneContainer);

            var contentHeight = this._contentBox.h - toolbarSize.h;
            domGeometry.setMarginBox(this._campaignFacet.domNode, { h: contentHeight });

            // Set the size of the marketing overview to be the content height minus the toolbar height and width minus the facet width.
            this.campaignItemList.resize({
                h: contentHeight,
                w: this._contentBox.w - leftPaneSize.w
            });
        },

        startup: function () {
            this.inherited(arguments);
            when(this.getCurrentContext(), this.contextChanged.bind(this));
            this.toolbar.setViewSelectorVisible(true);
        },

        contextChanged: function (ctx, callerData) {
            this.toolbar.update({
                currentContext: ctx
            });
        }
    });

});