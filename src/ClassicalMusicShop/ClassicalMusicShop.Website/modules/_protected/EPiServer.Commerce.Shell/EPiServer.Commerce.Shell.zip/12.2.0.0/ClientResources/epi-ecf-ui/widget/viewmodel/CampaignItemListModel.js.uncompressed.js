﻿define("epi-ecf-ui/widget/viewmodel/CampaignItemListModel", [
// dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
// epi-cms
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi-cms/component/command/ChangeContext",
    "epi-cms/command/NewContent",
// epi-ecf-ui
    "../../MarketingUtils",
    "../DeleteCampaignItemDialog",
    "./_MarketingListBaseModel",
// resources
    "epi/i18n!epi/nls/commerce.widget.marketingitemlist",
    "epi/i18n!epi/nls/episerver.shared"
],
function (
// dojo
    array,
    declare,
    lang,
// epi-cms
    dependency,
    _Command,
    ChangeContext,
    NewContent,
// epi-ecf-ui
    MarketingUtils,
    DeleteCampaignItemDialog,
    _MarketingListBaseModel,
// resources
    resources,
    sharedResources
) {
    return declare([_MarketingListBaseModel], {

        postscript: function () {
            var registry = dependency.resolve("epi.storeregistry");
            this._marketingStatisticsStore = registry.get("epi.commerce.marketingstatistics");

            this.inherited(arguments);
            this._setupCommands();
        },

        getRedemptions: function (promotionLinks) {
            // summary:
            //      Get redemption number for entire promotions under the given campaign.
            // promotionLinks: [Array]
            //      Collection of promotion link.
            // tags:
            //      public

            var query = {
                query: "getRedemptions",
                contentLinks: promotionLinks
            };

            return this._marketingStatisticsStore.query(query);
        },

        getOrderCounts: function (contentLinks) {
            // summary:
            //      Gets total order count for the given campaigns/promotions.
            // contentLinks: [Array]
            //      Collection of campaign/promotion link.
            // tags:
            //      public

            var query = {
                query: "getOrderCounts",
                contentLinks: contentLinks
            };

            return this._marketingStatisticsStore.query(query);
        },

        _setupCommands: function () {
            // Reset commands list.
            this.commands.length = 0;

            this.commands.push(new ChangeContext({
                category: "context",
                forceContextChange: true
            }));

            this.commands.push(new NewContent({
                category: "context",
                contentType: MarketingUtils.contentTypeIdentifier.promotionData,
                label: resources.createpromotion
            }));

            this.commands.push(this.createDeleteCommand(true));
        },

        createDeleteCommand: function (useContextMenu) {
            var deleteCommand = new _Command({
                store: this.store,
                iconClass: "epi-iconClose",
                label: sharedResources.action.deletelabel,
                canExecute: false,
                _onModelChange: function () {
                    this.set("canExecute", !!this.get("model"));
                },
                _execute: function () {
                    var dialog = new DeleteCampaignItemDialog({
                        contentData: this.get("model"),
                        store: this.store
                    });
                    dialog.show();
                }
            });

            if (useContextMenu) {
                deleteCommand.set("category", "context");
            }
            
            return deleteCommand;
        }
    });
});